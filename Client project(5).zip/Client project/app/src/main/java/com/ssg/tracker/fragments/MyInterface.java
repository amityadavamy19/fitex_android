package com.ssg.tracker.fragments;

public interface MyInterface {
    public void prevClick();
    public void nextClick();
}