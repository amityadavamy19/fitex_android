package com.ssg.tracker.model;

public class OtpModel {
    private String response_code;
    private String otp;


    // Getter Methods

    public String getResponse_code() {
        return response_code;
    }

    public String getOtp() {
        return otp;
    }

    // Setter Methods

    public void setResponse_code(String response_code) {
        this.response_code = response_code;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }
}
