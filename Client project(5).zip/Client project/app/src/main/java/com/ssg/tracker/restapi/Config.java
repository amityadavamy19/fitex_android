package com.ssg.tracker.restapi;

public class Config {

    public static final String API_BASE_URL = "https://fitex.co.in/Apicontrol/";
    public final static String API_KEY = "123456";
    public static String imagebase_url = "https://fitex.co.in/uploads/videos/";
    public final static String APP_ID = "api@fithub.com";
    public final static String deellink = API_BASE_URL+"deelink?id=";

}
